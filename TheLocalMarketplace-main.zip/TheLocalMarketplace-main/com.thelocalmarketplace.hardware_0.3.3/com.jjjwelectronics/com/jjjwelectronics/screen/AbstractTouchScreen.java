package com.jjjwelectronics.screen;

import com.jjjwelectronics.AbstractDevice;

abstract class AbstractTouchScreen extends AbstractDevice<TouchScreenListener> implements ITouchScreen {
}